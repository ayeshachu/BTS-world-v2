import 'package:flutter/material.dart';

import '../widgets/custom_drawer.dart';
import 'favorites_screen.dart';
import 'gallery_screen.dart';
import 'quotes_menu.dart';
import 'rate_screen.dart';
import 'search_screen.dart';
import 'wallpaper_menu.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void _open(BuildContext context, Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    const purple = Color(0xFF7B2CBF);
    const deepPurple = Color(0xFF240046);

    return Scaffold(
      drawer: const CustomDrawer(),
      appBar: AppBar(
        title: const Text('BTS Army World', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            tooltip: 'Search',
            icon: const Icon(Icons.search_rounded),
            onPressed: () => _open(context, const SearchScreen()),
          ),
          IconButton(
            tooltip: 'Favorites',
            icon: const Icon(Icons.favorite_rounded),
            onPressed: () => _open(context, const FavoritesScreen()),
          ),
          PopupMenuButton<String>(
            tooltip: 'More',
            onSelected: (value) {
              if (value == 'rate') {
                showDialog(context: context, builder: (_) => const RateScreen());
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'rate', child: Text('Rate this app')),
            ],
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFFF8FF), Color(0xFFF1E7FF), Color(0xFFFDFBFF)],
          ),
        ),
        child: SafeArea(
          top: false,
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(22),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF9D4EDD), Color(0xFF5A189A), Color(0xFF240046)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(28),
                    boxShadow: [
                      BoxShadow(
                        color: purple.withOpacity(.25),
                        blurRadius: 20,
                        offset: const Offset(0, 9),
                      ),
                    ],
                  ),
                  child: Stack(
                    children: [
                      const Positioned(
                        right: -8,
                        top: -12,
                        child: Icon(Icons.auto_awesome, size: 92, color: Color(0x33FFFFFF)),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(.18),
                              borderRadius: BorderRadius.circular(30),
                            ),
                            child: const Text('WELCOME, ARMY 💜',
                              style: TextStyle(color: Colors.white, fontSize: 11, letterSpacing: 1.2, fontWeight: FontWeight.w800)),
                          ),
                          const SizedBox(height: 14),
                          const Text('Your little purple universe',
                            style: TextStyle(color: Colors.white, fontSize: 25, height: 1.15, fontWeight: FontWeight.w900)),
                          const SizedBox(height: 8),
                          Text('Wallpapers, quotes and BTS moments — all in one place.',
                            style: TextStyle(color: Colors.white.withOpacity(.88), height: 1.4, fontSize: 14)),
                          const SizedBox(height: 18),
                          FilledButton.icon(
                            style: FilledButton.styleFrom(
                              backgroundColor: Colors.white,
                              foregroundColor: deepPurple,
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                            ),
                            onPressed: () => _open(context, const WallpaperMenu()),
                            icon: const Icon(Icons.favorite_rounded, size: 18),
                            label: const Text('Explore the purple world', style: TextStyle(fontWeight: FontWeight.w800)),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 25),
                const Text('Your ARMY space', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: deepPurple)),
                const SizedBox(height: 5),
                Text('Pick your favourite corner 💜', style: TextStyle(color: Colors.deepPurple.shade300, fontSize: 13)),
                const SizedBox(height: 14),
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1.15,
                  children: [
                    _FeatureCard(
                      title: 'BTS Wallpapers',
                      subtitle: 'Save your favourites',
                      icon: Icons.wallpaper_rounded,
                      colors: const [Color(0xFFB5179E), Color(0xFF7209B7)],
                      onTap: () => _open(context, const WallpaperMenu()),
                    ),
                    _FeatureCard(
                      title: 'BTS Quotes',
                      subtitle: 'Words to keep close',
                      icon: Icons.format_quote_rounded,
                      colors: const [Color(0xFF7B2CBF), Color(0xFF3C096C)],
                      onTap: () => _open(context, const QuotesMenu()),
                    ),
                    _FeatureCard(
                      title: 'Daily Wallpaper',
                      subtitle: 'A little daily sparkle',
                      icon: Icons.auto_awesome_rounded,
                      colors: const [Color(0xFF6930C3), Color(0xFF5390D9)],
                      onTap: () => _open(context, const GalleryScreen(
                        title: 'Wallpaper of the Day',
                        category: 'daily',
                        isQuotes: false,
                      )),
                    ),
                    _FeatureCard(
                      title: 'My Favourites',
                      subtitle: 'Your saved collection',
                      icon: Icons.favorite_rounded,
                      colors: const [Color(0xFF9D4EDD), Color(0xFFF15BB5)],
                      onTap: () => _open(context, const FavoritesScreen()),
                    ),
                  ],
                ),
                const SizedBox(height: 22),
                Container(
                  padding: const EdgeInsets.all(17),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: const Color(0xFFE8D8FF)),
                  ),
                  child: Row(
                    children: [
                      Container(
                        height: 52,
                        width: 52,
                        decoration: BoxDecoration(
                          color: const Color(0xFFF1E5FF),
                          borderRadius: BorderRadius.circular(17),
                        ),
                        child: const Icon(Icons.groups_rounded, color: purple, size: 29),
                      ),
                      const SizedBox(width: 13),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Seven hearts, one family', style: TextStyle(fontWeight: FontWeight.w900, color: deepPurple, fontSize: 15)),
                            SizedBox(height: 4),
                            Text('Made with love for ARMY 💜', style: TextStyle(color: Colors.black54, fontSize: 12)),
                          ],
                        ),
                      ),
                      const Icon(Icons.favorite, color: Color(0xFFB5179E)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _FeatureCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final List<Color> colors;
  final VoidCallback onTap;

  const _FeatureCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.colors,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(23),
        onTap: onTap,
        child: Ink(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: colors,
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(23),
            boxShadow: [
              BoxShadow(
                color: colors.last.withOpacity(.18),
                blurRadius: 12,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(15),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  height: 43,
                  width: 43,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(.2),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(icon, color: Colors.white, size: 25),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 4),
                    Text(subtitle, style: TextStyle(color: Colors.white.withOpacity(.86), fontSize: 11)),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
